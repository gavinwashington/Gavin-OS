# Gavin OS Remote v6

## What it does
A touch-friendly phone/iPad remote for a Windows PC running Gavin OS. It sends arrow keys, Enter, Escape, Delete, and the Windows key to the PC. It does not open extra Gavin OS tabs.

## Start it
1. Extract the ZIP on your Windows PC.
2. Double-click `START_REMOTE.bat`.
3. If Windows Firewall asks, allow it on **Private networks** only.
4. On your phone/iPad, while connected to the same Wi-Fi, open the `http://...:8765/` address printed in the black server window.
5. Tap Connect, then use the remote. Keep the black server window open.

## Notes
- Gavin OS should be open on the PC. For keyboard navigation to work, its browser window should be focused.
- The Home button sends the Windows key; it does not launch another Gavin OS tab.
- This is for a trusted home network only. Stop the server with Ctrl+C when finished.
- If the page won't load, check that both devices use the same Wi-Fi and that Windows Firewall permits the connection on Private networks.
