$ErrorActionPreference = "Stop"
$Port = 8765
$Listener = [System.Net.HttpListener]::new()
$Listener.Prefixes.Add("http://+:$Port/")
try {
  $Listener.Start()
} catch {
  Write-Host "Could not start the remote server on port $Port." -ForegroundColor Red
  Write-Host "Try right-clicking START_REMOTE.bat and choosing Run as administrator."
  Read-Host "Press Enter to close"
  exit 1
}
Add-Type @"
using System;
using System.Runtime.InteropServices;
public class GavinRemoteKeys {
  [DllImport("user32.dll", SetLastError=true)] public static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, UIntPtr dwExtraInfo);
  public const uint KEYEVENTF_KEYUP = 0x0002;
  public static void Tap(byte key) { keybd_event(key, 0, 0, UIntPtr.Zero); keybd_event(key, 0, KEYEVENTF_KEYUP, UIntPtr.Zero); }
}
"@
$keys = @{
 "ArrowUp"=0x26; "ArrowDown"=0x28; "ArrowLeft"=0x25; "ArrowRight"=0x27
 "Enter"=0x0D; "Escape"=0x1B; "Delete"=0x2E; "Home"=0x5B
}
function Send-Key([string]$Name) {
  if ($Name -eq "Home") {
    # Tap the left Windows key.
    [GavinRemoteKeys]::Tap(0x5B)
  } elseif ($keys.ContainsKey($Name)) {
    [GavinRemoteKeys]::Tap([byte]$keys[$Name])
  }
}
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$htmlPath = Join-Path $root "index.html"
$ipList = Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object { $_.IPAddress -notlike "127.*" -and $_.IPAddress -notlike "169.254.*" } | Select-Object -ExpandProperty IPAddress -Unique
Write-Host ""
Write-Host "       GAVIN OS REMOTE" -ForegroundColor Magenta
Write-Host "Keep this window open while using the remote." -ForegroundColor Cyan
Write-Host ""
foreach ($ip in $ipList) { Write-Host "On your phone, open: http://${ip}:$Port/" -ForegroundColor Green }
Write-Host ""
Write-Host "If Windows Firewall asks, allow access on Private networks only."
Write-Host "Press Ctrl+C to stop the server."
while ($Listener.IsListening) {
  $ctx = $null
  try { $ctx = $Listener.GetContext() } catch { break }
  try {
    $req = $ctx.Request
    $res = $ctx.Response
    $res.Headers.Add("Cache-Control", "no-store")
    $res.Headers.Add("Access-Control-Allow-Origin", "*")
    $res.Headers.Add("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
    $res.Headers.Add("Access-Control-Allow-Headers", "Content-Type")
    if ($req.HttpMethod -eq "OPTIONS") {
      $res.StatusCode = 204
    } elseif ($req.Url.AbsolutePath -eq "/health") {
      $bytes = [Text.Encoding]::UTF8.GetBytes('{"ok":true}')
      $res.ContentType = "application/json; charset=utf-8"
      $res.OutputStream.Write($bytes,0,$bytes.Length)
    } elseif ($req.Url.AbsolutePath -eq "/" -or $req.Url.AbsolutePath -eq "/index.html") {
      if (Test-Path $htmlPath) {
        $bytes = [IO.File]::ReadAllBytes($htmlPath)
        $res.ContentType = "text/html; charset=utf-8"
        $res.OutputStream.Write($bytes,0,$bytes.Length)
      } else { $res.StatusCode = 404 }
    } elseif ($req.Url.AbsolutePath -like "/key/*" -and $req.HttpMethod -eq "POST") {
      $name = [Uri]::UnescapeDataString($req.Url.AbsolutePath.Substring(5))
      if ($keys.ContainsKey($name) -or $name -eq "Home") {
        Send-Key $name
        $bytes = [Text.Encoding]::UTF8.GetBytes('{"ok":true}')
        $res.ContentType = "application/json; charset=utf-8"
        $res.OutputStream.Write($bytes,0,$bytes.Length)
      } else { $res.StatusCode = 400 }
    } else { $res.StatusCode = 404 }
    $res.Close()
  } catch {
    try { $ctx.Response.StatusCode = 500; $ctx.Response.Close() } catch {}
  }
}
try { $Listener.Stop(); $Listener.Close() } catch {}
